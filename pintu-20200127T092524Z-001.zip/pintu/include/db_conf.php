<?php
session_start();
    $DBHOST="localhost";
	$DBUSER="root";
	$DBPASS="";
	$DBNAME="Bank";
?>
